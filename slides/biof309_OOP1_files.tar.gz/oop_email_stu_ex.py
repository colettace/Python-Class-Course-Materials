"""OBJECT-ORIENTED PROGRAMMING EXAMPLE"""

import smtplib # Simple Mail Transfer Protocol

class Student( object ):
	"""Defines the "Student" class"""

	# Class attributes: values which all instances share
	# keeps track of all Students instantiated
	list_of_all_students = []

	# Any function built into a class is called a method.
	# Any time a method is called, the instance upon which it's called
	# is passed to the method as the first argument.
	def __init__( self, line ):
		# self.lname, self.fname, etc are INSTANCE ATTRIBUTES
		# i.e., each instance has their own separate values
		self.lname, self.fname, self.email, grades = line.split( '\t', 3 )
		self.hw1, self.hw2, self.hw3, self.hw4, self.final_proj = \
				[ float( grade ) for grade in grades.split('\t') ]

		# add this instance to the class attribute list
		self.list_of_all_students.append( self )


	def CalcFinalGrade( self ):
		self.final_grade = 0.8 * ( self.hw1 + self.hw2 + self.hw3 + self.hw4 ) / 4 \
		                   + 0.2 * self.final_proj

	def EmailFinalGrade( self, email_conn ):
		message = "{}, you got a {}!".format( self.fname, self.final_grade )
		email_conn.sendmail( 'chris@gmail.com', [self.stu_email], message )

# Main program
if __name__ == '__main__':

	with open( 'student_data.txt' ) as the_file:
		for the_line in the_file:
			the_student = Student( the_line )
			the_student.CalcFinalGrade()
	
	for the_student in Student.list_of_all_students:
		print the_student.fname, the_student.final_grade


	email_students = False
	if email_students:
		# Setup connection w/ Gmail server
		gmail_conn = smtplib.SMTP( 'smtp.gmail.com', 587 )
		gmail_conn.ehlo()
		gmail_conn.starttls()
		gmail_conn.login( 'chris@gmail.com', 'my_pword')

		for the_student in Student.list_of_all_students:
			the_student.EmailFinalGrade( gmail_conn )

		gmail_conn.quit()


