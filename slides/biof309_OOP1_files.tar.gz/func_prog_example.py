"""FUNCTIONAL PROGRAMMING EXAMPLE"""

import smtplib # Simple Mail Transfer Protocol

#	Define helper functions
def CalculateFinalGrade( hw1, hw2, hw3, hw4, finalproj ):
	return 0.8 * ( hw1 + hw2 + hw3 + hw4 ) / 4 + 0.2 * final_proj

def EmailStudentFinalGrade( email_conn, fname, stu_email, grade ):
	message = “{}, you got a {}!”.format( fname, grade )
	email_conn.sendmail( 'chris@gmail.com', [stu_email], message )

# Main program
if __name__ == '__main__':

	# Setup connection w/ Gmail server
	gmail_conn = smtplib.SMTP( 'smtp.gmail.com', 587 )
	gmail_conn.ehlo()
	gmail_conn.starttls()
	gmail_conn.login( 'chris@gmail.com', ‘my_pword’)

	with open( student_data.txt ) as the_file:
		for the_line in the_file:
			lname, fname, stu_email, the_grades = line.split( ' ', 3 )
			hw1, hw2, hw3, hw4, final_proj = \
			             [ float( grade ) for grade in the_grades.split() ]
			final_grade = CalculateFinalGrade( hw1, hw2, hw3, hw4, final_proj )
			EmailStudentFinalGrade( gmail_conn, fname, stu_email, final_grade )

	gmail_conn.quit()


